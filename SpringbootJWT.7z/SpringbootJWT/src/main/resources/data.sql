insert into sec_user(id, user_name, password,roles) values(1,'Pmella','1234','ADMIN');
insert into sec_user(id, user_name, password,roles)
 values(2,'Johndoe','1234','USER');
insert into sec_user(id, user_name, password,roles) 
values(3,'Cathy','1234','HR');

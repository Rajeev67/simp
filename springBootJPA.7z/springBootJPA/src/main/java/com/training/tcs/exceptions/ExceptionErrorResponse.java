package com.training.tcs.exceptions;

import java.util.Date;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Setter
@Getter
public class ExceptionErrorResponse {
	private String message;
	private String errorCode;
	private Date time;
}

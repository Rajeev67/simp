package com.training.tcs.exceptions;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@RestControllerAdvice

public class GlobalExceptionHandler //extends ResponseEntityExceptionHandler  
	{

//	@ExceptionHandler(value = { NullPointerException.class })
//	@ResponseStatus(HttpStatus.NOT_ACCEPTABLE)
//	protected ResponseEntity<Object> errorHandler(NullPointerException e, WebRequest req) {
//		ExceptionErrorResponse error = new ExceptionErrorResponse();
//		error.setMessage(e.getMessage());
//		error.setErrorCode("406");
//		error.setTime(new java.util.Date());
//
//		return handleExceptionInternal(e, error, new HttpHeaders(), HttpStatus.NOT_ACCEPTABLE, req);
//	}
//	
//	@ExceptionHandler(value = { Exception.class })
//	@ResponseStatus(HttpStatus.NOT_FOUND)
//	protected ResponseEntity<Object> errorHandlerNotFound(Exception e, WebRequest req) {
//		ExceptionErrorResponse error = new ExceptionErrorResponse();
//		error.setMessage(e.getMessage());
//		error.setErrorCode("404");
//		error.setTime(new java.util.Date());
//
//		return handleExceptionInternal(e, error, new HttpHeaders(), HttpStatus.NOT_FOUND, req);
//	}
//
//	
//	@ExceptionHandler(value = {InvalidValueException.class })
//	@ResponseStatus(HttpStatus.BAD_REQUEST)
//	protected ResponseEntity<Object> errorHandlerInvalidValue(InvalidValueException e, WebRequest req) {
//		ExceptionErrorResponse error = new ExceptionErrorResponse();
//		error.setMessage(e.getMessage());
//		error.setErrorCode("400");
//		error.setTime(new java.util.Date());
//
//		return handleExceptionInternal(e, error, new HttpHeaders(), HttpStatus.BAD_REQUEST, req);
//	}
	
	 @ResponseStatus(HttpStatus.BAD_REQUEST)
	    @ExceptionHandler(value={MethodArgumentNotValidException.class})
	    public Map<String,String> handleInvalidArguments(MethodArgumentNotValidException ex ,WebRequest req){
	        Map<String,String> errorMap = new HashMap<>();
	        
	          ex.getBindingResult().getFieldErrors().forEach (error -> {
	                errorMap.put(error.getField(),error.getDefaultMessage());
	            });
	        
	        return errorMap;
	    }
	 
	 @ResponseStatus(HttpStatus.BAD_REQUEST)
	    @ExceptionHandler(value={ProductNotFoundException.class})
	    public Map<String,String> handleInvalidArguments(ProductNotFoundException ex ,WebRequest req){
	        Map<String,String> errorMap = new HashMap<>();
	        
	          errorMap.put("error message",ex.getMessage());
	        
	        return errorMap;
	    }
}
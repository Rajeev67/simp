package com.training.tcs;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.training.tcs.entity.Product;
import com.training.tcs.repository.ProductRepository;


@SpringBootApplication
public class SpringBootJpaApplication{ //implements CommandLineRunner {

//	@Autowired
//	ProductRepository repository;
//	
	
	public static void main(String[] args) {
		SpringApplication.run(SpringBootJpaApplication.class, args);
		
	}
	
//	@Override   // to store data directly into database (without repository,service )
//	public void run(String...args) throws Exception{
//		repository.save(new Product("abc","def",1,22.0));
//		repository.save(new Product());
//	}
	
	

	@Bean
	CommandLineRunner commandLineRunner(ProductRepository repository) {
		return arcs -> {
			Product p1 = Product.builder().
//			id(0).
			name("Inpiron15").
			description("Dell Laptop").
			qty(1).
			price(95000).
			build();			
			repository.save(new Product(p1));
//			repository.save(new Product());
		};
	}
	
}



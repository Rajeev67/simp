package com.training.tcs.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.tcs.dto.ProductRequest;
import com.training.tcs.entity.Product;
import com.training.tcs.exceptions.ProductNotFoundException;
import com.training.tcs.exceptions.ProductNotFoundException;
import com.training.tcs.repository.ProductRepository;

import jakarta.transaction.Transactional;

@Service
public class ProductService {
	
//	private final ProductRepository repository;
//	
//	public ProductService(ApplicationContext context) {
//		this.repository = context.getBean(ProductRepository.class);
//	}

//	ProductRepository repository = context.getBean("ProductRepository.class");
	
	@Autowired
	ProductRepository repository;
	
	public List<Product> getProducts(){
		return repository.findAll();
	}
	
	public Product getById(Long id) throws ProductNotFoundException {
		
		Optional optional = repository.findById(id);
		if(optional.isPresent())
			return (Product) optional.get();
		else
			throw new ProductNotFoundException("no product with the given id");
	}
	
	
	public Product saveProduct(ProductRequest productDTO) {
		Product productEntity = Product.builder()
												.id(0)
												.name(productDTO.getName())
												.description(productDTO.getDescription())
												.qty(productDTO.getQty())
												.price(productDTO.getPrice())
												.build();
		return repository.save(productEntity);
	}
	
	public List<Product> saveProducts(List<Product> product) {
		return repository.saveAll(product);
	}
	
	public Product updateProduct(Product product) {
		return repository.save(product);
	}
	
	public void deleteById(long id) {
		repository.deleteById(id);
	}
	
	public Product getByName(String name) {
		return repository.findByName(name);
	}
	
	@Transactional
	public void deleteByName(String name) {
		repository.deleteByName(name);
	}
	
	public List<Product> getByQtyLessThan(int qty) {
		return repository.findByQtyLessThan(qty);
	}
	
	public List<Product> getQtyBetween(int qty1,int qty2){
		return repository.findByQtyBetween(qty1,qty2);
	}
	
	public List<Product> getAll(){
		return repository.findAll();
	}
}

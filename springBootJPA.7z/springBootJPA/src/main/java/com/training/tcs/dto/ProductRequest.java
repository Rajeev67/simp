package com.training.tcs.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor(staticName = "build")
@NoArgsConstructor
public class ProductRequest {
//	private long id;
	@NotNull(message = "username shouldn't be null")
	@NotBlank(message = "username cannot be blank")
	private String name;
	
	@NotNull(message = "description shouldn't be null")
	@NotBlank(message = "description cannot be blank")
	private String description;
	
	@Min(value = 1,message = "value cannot be less than 1")
	@Max(value = 1000,message = "value cannot be greater than 1000")
	private int qty;
	
	@NotNull(message = "price shouldn't be null")
	@Min(value = 1,message = "Value cannot be less than 1")
	@Max(value = 10000,message = "Value cannot be greater than 10000")
	private double price;
}

package com.training.tcs.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@EqualsAndHashCode
@NoArgsConstructor
@Builder
@AllArgsConstructor
@Data
@Entity
@Table(name = "tcsproducts")
public class Product {
//	public long getId() {
//		return id;
//	}
//	public void setId(long id) {
//		this.id = id;
//	}
//	public String getName() {
//		return name;
//	}
//	public void setName(String name) {
//		this.name = name;
//	}
//	public String getDescription() {
//		return description;
//	}
//	public void setDescription(String description) {
//		this.description = description;
//	}
//	public int getQty() {
//		return qty;
//	}
//	public void setQty(int qty) {
//		this.qty = qty;
//	}
//	public double getPrice() {
//		return price;
//	}
//	public void setPrice(double price) {
//		this.price = price;
//	}
	@Id   // primary id
	@GeneratedValue(strategy = GenerationType.IDENTITY) // to generate primary key automatically
	private long id;
	private String name;
	private String description;
	private int qty;
	private double price;
	
	
	
//	public Product() {
//		
//	}
//	public Product(String name, String description, int qty, double price) {
//		super();
//		this.name = name;
//		this.description = description;
//		this.qty = qty;
//		this.price = price;
//	}



	public Product(Product p1) {
		// TODO Auto-generated constructor stub
	}
	
}

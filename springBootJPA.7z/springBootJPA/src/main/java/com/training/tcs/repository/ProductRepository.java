package com.training.tcs.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.training.tcs.entity.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long>{
	public Product findByName(String name);
	public void deleteByName(String name);
	public List<Product> findByQtyLessThan(int qty);
	public List<Product> findByQtyBetween(int qty1,int qty2);


	@Query("SELECT t FROM Product t")
	List<Product> findAll();
	
	@Query("SELECT t FROM Product t WHERE t.description LIKE %?1%")
	List<Product> findByDescription(String description);
}

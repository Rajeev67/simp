package com.training.tcs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.http.*;

import com.training.tcs.dto.ProductRequest;
import com.training.tcs.entity.Product;
import com.training.tcs.exceptions.ProductNotFoundException;
import com.training.tcs.service.ProductService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/product/api")
public class ProductController {
	@Autowired
	ProductService service;
	
//	@GetMapping("/catalog")
	@GetMapping(value = "/catalog")
	@RequestMapping(value = "/catalog",
							produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.TEXT_PLAIN_VALUE}
	)
	public List<Product> productList(){
		return service.getProducts();
	}
	
	
	@GetMapping("/findAll")
	public List<Product> getAll(){
		return service.getAll();
	}
	
	@GetMapping("findById/{id}")
	public Product findById(@PathVariable Long id) throws ProductNotFoundException {
		return service.getById(id);
	}
	
	
	//REST principle -> Content negotiation
	
//	@PostMapping("/addProduct")
	@PostMapping(value = "/addProduct",
	consumes = {MediaType.APPLICATION_JSON_VALUE,MediaType.TEXT_PLAIN_VALUE},
	produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.TEXT_PLAIN_VALUE}
)
	public Product saveProduct(@RequestBody @Valid ProductRequest product) {
		return service.saveProduct(product);
	}
	
	@PostMapping("/addAllProduct")
	public List<Product> saveProducts(@RequestBody List<Product> product) {
		return service.saveProducts(product);
	}
	
	@PutMapping("/modify")
	public Product change(@RequestBody Product product) {
		return service.updateProduct(product);
	}
	
	@DeleteMapping("/deleteById/{id}")
	public void deleteById(@PathVariable long id) {
		service.deleteById(id);
	}
	
	@GetMapping("getByName/{name}")
	public Product getByName(@PathVariable String name) {
		return service.getByName(name);
	}
	
	@DeleteMapping("/deleteByName/{name}")
	public void deleteByName(@PathVariable String name) {
		service.deleteByName(name);
	}
	
	@GetMapping("/findBYQtyLessThan/{qty}")
	public List<Product> getByQtyLessThan(@PathVariable int qty) {
		return service.getByQtyLessThan(qty);
	}
	
	@GetMapping("/findBYQtyBetween/qty-range")
	public List<Product> getQtyBetween(@RequestParam int qty1,@RequestParam int qty2){
		return service.getQtyBetween(qty1,qty2);
	}
	
//	@PostMapping("/persist")
//	@ResponseStatus(HttpStatus.CREATED)
//	public List<Product> voidback() {
//		return service.getAll();
////		return ;
//	}
	
	
	//"*" can be used to map any input data
	@PostMapping(value = "/persist",
			consumes = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE},
			produces = MediaType.APPLICATION_JSON_VALUE
		)
//	@PostMapping("/persist")
	public ResponseEntity<Product> persist(@RequestBody @Valid ProductRequest product) {
		 Product tempProduct = service.saveProduct(product);
		 HttpHeaders myHttpHeader = new HttpHeaders();
		 myHttpHeader.add("xx-my-header","today is good day");
//		 return ResponseEntity.status(HttpStatus.CREATED).headers(myHttpHeader).body(tempProduct);
		 return ResponseEntity.ok(tempProduct);
	}
}

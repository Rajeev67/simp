package com.training.tcs.exceptions;

public class InvalidValueException extends Exception{
	public InvalidValueException(String message) {
		super(message);
		
	}
}

package com.training.tcs.model;

public record Product(Long id,String name,String description,int qty,double price) {

}

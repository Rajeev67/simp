package com.training.tcs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

import com.training.tcs.model.Product;

@SpringBootApplication
public class SpringbootJpaClientApplication {

	public static void main(String[] args) {
		Product product = new Product(1L,"abc","def",10,100);
		SpringApplication.run(SpringbootJpaClientApplication.class, args);
	}
	
	@Bean
	public RestTemplate newTemplate() {
		return new RestTemplate();
	}
}

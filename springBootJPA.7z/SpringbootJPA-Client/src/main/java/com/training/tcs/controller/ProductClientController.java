package com.training.tcs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.training.tcs.model.Product;

@RestController
@RequestMapping("/product")
public class ProductClientController {
	
	
	@Autowired
	RestTemplate template;
	
//	@GetMapping("/viewcatalog")
//	public List<Product> catalog(){
//		String url = "http://localhost:8095/product/api/catalog";
//		List<Product> list = template.getForObject(url,List.class);
//		return list;
//		
//	}
	
	@GetMapping("/viewcatalog")
	public List<Product> catalog() {
	    String url = "http://localhost:8095/product/api/catalog";

	    ResponseEntity<List<Product>> response = template.exchange(
	        url,
	        HttpMethod.GET,
	        null,
	        new ParameterizedTypeReference<List<Product>>() {}
	    );

	    return response.getBody();
	}
	
	
	@GetMapping("/viewByName/{name}")
	public Product viewByName(@PathVariable("name") String name) {
		String url = "http://localhost:8095/product/api/getByName/"+name;
		Product product = template.getForObject(url,Product.class);
		return product;
	}
	
	
	@GetMapping("/viewById/{Id}")
	public Product viewByName(@PathVariable("Id") Long Id) {
		String url = "http://localhost:8095/product/api/findById/"+ Id;
		Product product = template.getForObject(url,Product.class);
		return product;
	}
	
	
	@GetMapping("/deleteById/{Id}")
	public boolean deleteById(@PathVariable("Id") Long Id){
		String url = "http://localhost:8095/product/api/deleteById/"+ Id;
		template.delete(url);
		return true;
	}
	
	
	
//	@GetMapping("/viewbyid/{id}")
//	public Product catalog(@PathVariable("id") Long id){
//		String url = "http://localhost:8095/product/api.1.0/catalog";
//		Product product = template.getForObject(url,Product.class);
//		return product;
//		
//	}
	
}
